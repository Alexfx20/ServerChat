package ru.secondchat.client;



import ru.secondchat.network.Connection;
import ru.secondchat.network.ConnectionListener;

import java.io.IOException;
import java.util.Scanner;

public class Client implements ConnectionListener {

    private static final String IP = "127.0.0.1";
    private static final int PORT = 5000;
    private static Connection connection;
    Scanner sc;
    String name;
    String status;


    public static void main(String[] args) {
        new Client();

    }

    public Client() {
        try {
            sc=new Scanner(System.in);

            this.connection = new Connection(this, IP,PORT);
            this.onConnectionReady(connection);
            this.onRegistration(connection);
            connection.startNewChat();
            transmitMessage();
        } catch (IOException e) {
            System.out.println("Connection Exception: "+e);
        }

    }

    @Override
    public void onConnectionReady(Connection connection) {
        try{
        if(connection!=null)
            System.out.println(connection.recieveSingleMessage());
        else System.out.println("Server is unavailable, try again later");}
        catch(IOException e){}

    }

    @Override
    public void onRegistration(Connection connection) {
        try{

                System.out.print(connection.recieveSingleMessage()+" ");
                name = sc.nextLine();
                connection.sendMessage(name);
                System.out.print(connection.recieveSingleMessage()+" ");
                status = sc.nextLine();
                connection.sendMessage(status);


        }
        catch(IOException e){
            System.out.println("Something bad happening...");
        }

    }

    @Override
    public void onReciveMessage(Connection connection, String value) {
        // try{
        processCommands(value);
        printMessage(value);//здесь была строка connection.recieveSingleMessage() в сигнатуре метода printMessage

        //}
        // catch(IOException e){}                              // метод recieve стоит включить в сигнатуру если его используют при вызове onRecieve
                                                            // если же в onrecieve в сигнатуре расположен in.readline то тогда в printmessage необходимо передавать value
    }

    @Override
    public void onDisconnect(Connection connection) {
        printMessage("You've been disconnected");
        connection.disconnect();

    }

    @Override
    public void onException(Connection connection, Exception e) {
        System.out.println("Connection Exception: "+e);

    }

    @Override
    public void processCommands(String value) {
        if(value.endsWith("./")){
            connection.sendMessage("/endOfChat");
        }
        else if(value.startsWith("/Session")){
            onDisconnect(connection);
        }

    }

    private synchronized void printMessage(String message){
        System.out.println(message);

    }

    private void transmitMessage(){
        String mes;
        while(!(mes=sc.nextLine()).equals("/exit")){
            connection.sendMessage(mes);
        }
        connection.sendMessage(mes);
        onDisconnect(connection);

    }
}

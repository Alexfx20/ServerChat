package ru.secondchat.server;

import ru.secondchat.network.Connection;
import ru.secondchat.network.ConnectionListener;



import java.io.IOException;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.Date;

 public class ClientHandler implements Runnable, ConnectionListener {
      //тут начинается

        private ClientHandler recipientClient;//ссылка на собеседника

        private Connection recipient;//ссылка на соединение с собесдеником
        private Connection handlingUser;//ссылка на свое соединение
        private Socket socketIN;//свой сокет
        private String name = "";//имя пользователя
        private String status = "";//статус
        int i;//бесполезная переменная
        private String firstMessage="";//сообщение от данного клиента
        private boolean isReadyToChat = true;//флаг при тру поток находится в цикле с методом onrecive
        private boolean isExit = false;//флаг указывает вышел ли собеседник из чата, либо просто набрал команду /leave и весит в ожидании

        public ClientHandler(Socket socket, int i){
            socketIN = socket;
            this.i = i;
        }


        @Override
        public void run() {
            //
            try{

                handlingUser = new Connection(this, socketIN);// создаем соединение - ин аут потоки связанные с сокетом
                this.onConnectionReady(handlingUser);//вызываем метод подтверждающий что соединение с сервером установлено
                this.onRegistration(handlingUser);// регистрируемся на сервере
                while(!isExit) {//До тех пор пока пользователь не ввел команду /exit повторяем цикл
                    socketIN.setSoTimeout(120000);//в режиме ожидания когда пользователь обдумывает свое первое сообщение устанавливаем тайм аут 2 мин для соединения
                    this.onHold();//вызываем метод, который ожидает пользовательского ввода первого сообщения, после чего помещаем пользователя в очередь
                    socketIN.setSoTimeout(600000);// увеличиваем тайм аут до 10 минут на время коммуникации с агентом
                    while(isReadyToChat) {
                        try{
                        this.onReciveMessage(handlingUser, handlingUser.recieveSingleMessage());}//ожидаем сообщения от пользователя в случае получения пересылаем его агенту
                        catch(SocketTimeoutException e){
                            if(recipient!=null){handlingUser.sendMessage("/Session reached Timeout" );
                            onException(handlingUser, e);
                            }
                        }
                    }
                }
            }
            catch(SocketTimeoutException e){
                System.out.println("Время ожидания превышено");
                handlingUser.sendMessage("/Session reached Timeout" );
                this.onException(handlingUser, e);
            }
            catch (IOException e){
                System.out.println("incoming connection has just failed. Congratulations with: "+e);
                this.onException(handlingUser, e);
            }
            //finally{this.onDisconnect(handlingUser);}

        }


        private void onHold() throws IOException{
            recipient = null;
            recipientClient = null;
            isReadyToChat = true;

                    if (status.equals("client")) {
                    handlingUser.sendMessage("Write a question, to start the chat");//ждем первого сообщения от пользователя

                    try {
                        firstMessage = handlingUser.recieveSingleMessage();
                        if((firstMessage.equals("/exit")||firstMessage.equals("/leave"))){
                            this.onReciveMessage(handlingUser,firstMessage);
                            isReadyToChat = false;
                            return;
                        }// если сообщение не является командой помещаем пользоватея в очередь

                            handlingUser.sendMessage("Hold on please, you are the "+(Server.customers.size()+1)+" in the queue");
                        Server.customers.put(this);}

                    catch (SocketTimeoutException e) {
                        handlingUser.sendMessage("/Session reached Timeout");
                        onException(handlingUser, e);
                        return;
                    }
                    catch (InterruptedException e){
                        System.out.println("Поток прерван в процессе ожидания");
                        this.onException(handlingUser, e);
                    }

                 }
                else {
                    handlingUser.sendMessage("looking for new customers, wait please, you are the "+(Server.agents.size()+1)+" among agents");
                    try {
                        firstMessage = String.format("Agent %s on-line", name);
                        Server.agents.put(this);

                    } catch (InterruptedException e) {
                        System.out.println("не ждет!!!");
                        this.onException(handlingUser, e);
                    }


                }
        }

        public void setRecipient (ClientHandler recipientClient, Connection recipient){
            this.recipient = recipient;
            this.recipientClient = recipientClient;
        }

     public void setHandlingUser(Connection handlingUser) {
         this.handlingUser = handlingUser;
     }

     public String getName() {
         return name;
     }

     public Connection getHandlingUser() {
         return handlingUser;
     }
     public Connection getRecipient() {
         return recipient;
     }


     public String getFirstMessage() {
         return firstMessage;
     }

     public void setReadyToChat(boolean readyToChat) {
         isReadyToChat = readyToChat;
     }

     public void processCommands(String value){
            if(value.equals("/leave")){
                isReadyToChat = false;
                if(recipientClient!=null){
                recipientClient.setReadyToChat(false);
                recipient.sendMessage(String.format("%s has just left the chat./", name));}
                System.out.println(status+" "+name+"has ended chat at "+new Date());
            }
            else if(value.equals("/exit")){
                isReadyToChat = false;
                if(recipientClient!=null)
                recipientClient.setReadyToChat(false);
                recipient.sendMessage("has exit the program./");
                isExit = true;
                System.out.println(status+" "+name+" has exit the program at "+new Date());

                }
                else if(value.equals("/endOfChat"));
                //залогировать событие
     }

     @Override
     public synchronized void onConnectionReady(Connection connection) {

         System.out.println("Client connected: "+connection);
         connection.sendMessage("Client connected: "+connection);
         //надо залогировать Log.add(String event);

     }

     @Override
     public synchronized void onRegistration(Connection handlingUser) {
         try{

             handlingUser.sendMessage("Please enter your name: ");
             name = handlingUser.recieveSingleMessage();
             System.out.println(name);
             handlingUser.sendMessage("Please enter your password: ");
             status = handlingUser.recieveSingleMessage();
             if(status.equals("agent")||status.equals("client")){

                 handlingUser.sendMessage("Registration completed. Good day "+name);
                 System.out.println("Имя посетителя: "+name+" статус посетителя: "+ status+" Время входа в систему: "+new Date());
                 //залогировать систему здесь может лучше???
             }

             else throw new IOException(); //здесь залогировать систему несанкционированный доступ
         }
         catch (SocketTimeoutException e){
             System.out.println("Превышено время ожидания");
             handlingUser.sendMessage("/Session reached Timeout");
             onDisconnect(handlingUser);//Залогировать
         }
         catch (IOException e){
             System.out.println("Registration failed");
             handlingUser.sendMessage("Registration failed. Bye Bye "+name);
             onDisconnect(handlingUser);
         }
     }

     @Override
     public synchronized void onReciveMessage(Connection connection, String value) {
         firstMessage = value;
         if(value.startsWith("/")){
             processCommands(value);//данный метод обрабатывает команды с консоли
         }
            else
         sendToAllConnections(firstMessage);

     }

     @Override
     public synchronized void onDisconnect(Connection connection) {

         sendToAllConnections("Client disconnected: "+connection.toString());
         connection.disconnect();
         handlingUser = null;
         try {
             finalize();
         } catch (Throwable throwable) {
             throwable.printStackTrace();
         }

     }

     @Override
     public synchronized void onException(Connection connection, Exception e) {
         System.out.println("Connection Exception: "+ e);
         onDisconnect(connection);

     }

     private void sendToAllConnections(String message){
         System.out.println(name+" "+message);

         if(handlingUser!=null)
             handlingUser.sendMessage(status+" "+name+" : "+message);
         if(recipient!=null){
             recipient.sendMessage(status+" "+name+" : "+message);}


     }






}

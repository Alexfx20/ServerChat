package ru.secondchat.server;

import java.util.Date;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Switcher extends Thread{
    static private ClientHandler client;
    static private ClientHandler agent;
    Lock lock = new ReentrantLock();

    @Override
    public void run() {
        while(!Thread.currentThread().isInterrupted()){
           /* if(Server.customers.isEmpty()||Server.agents.isEmpty()){// если одна из очередей пуста, то ждем

                try {
                    Thread.sleep(5000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

            }
            else{    */                           //если в очередях есть кто-то то пытаемся их соединить
                try {

                agent = Server.agents.take();       //берем агента

                    synchronized (agent) {      //Теперь синхронизируем его, чтобы он случайно не вышел  в другом потоке
                        if(agent.getHandlingUser()!=null) { //т.к. не проиходит удаление клиентов из очереди при их выходе, то проверяем не вышел ли клинет в процессе ожидания
                            client = Server.customers.take();// если клинет вышел, то ссылка на его соединение обнуляется, достаем агента из очереди
                            synchronized (client) {// теперь берем клинета и делаем с ним тоже самое
                                if(client.getHandlingUser()!=null){
                                agent.setRecipient(client, client.getHandlingUser());//устанавливаем получателя агенту
                                client.setRecipient(agent, agent.getHandlingUser());//устанавливаем получателя клиенту
                                agent.getHandlingUser().sendMessage(client.getFirstMessage());//оповещаем клинета об установленном соединении
                                client.getHandlingUser().sendMessage(agent.getFirstMessage());//оповещаем агетна об установленном соединении
                                    System.out.println("Клиент "+client.getName()+" connected to "+agent.getName()+" at "+new Date());

                                }
                                else Server.agents.put(agent);//если вдруг оказалось, что клиент вышел, то возвращаем агента обратно в очередь, и ожидаем нового клиента
                            }
                        }

                    }
                    } catch (InterruptedException e) {
                    e.printStackTrace();
                }

            //}
        }
    }
}

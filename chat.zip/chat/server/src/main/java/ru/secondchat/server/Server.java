package ru.secondchat.server;


import ru.secondchat.network.Connection;


import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.*;
import java.util.concurrent.*;


public class Server {

    private int PORT;
    private static int MAX_ALLOWED_CONNECTIONS;
    private int MAX_MINUTES_ONLINE;
    private static int MAX_AGENTS;
    private static Properties properties;


    static LinkedBlockingQueue<ClientHandler> customers;
    static LinkedBlockingQueue<ClientHandler> agents;
    static int k = 0;

    static{
        try {
            properties = new Properties();
            properties.load(new FileInputStream("Settings.prop"));
            MAX_ALLOWED_CONNECTIONS = Integer.parseInt(properties.getProperty("MAX_ALLOWED_CONNECTIONS"));
            MAX_AGENTS = Integer.parseInt(properties.getProperty("MAX_AGENTS"));
            customers = new LinkedBlockingQueue<>(MAX_ALLOWED_CONNECTIONS-MAX_AGENTS);
            agents = new LinkedBlockingQueue<>(MAX_AGENTS);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        catch (IOException e){e.printStackTrace();}

    }

    public static void main(String[] args) {

        new Server().go();

    }

    public Server() {
        PORT = Integer.parseInt(properties.getProperty("PORT"));
        MAX_MINUTES_ONLINE = Integer.parseInt(properties.getProperty("MAX_MINUTES_ONLINE"));

        System.out.println("Server running... " + new Date());

    }

    private void go(){
        ExecutorService pool = Executors.newFixedThreadPool(MAX_ALLOWED_CONNECTIONS);
        new Switcher().start();
        ((ThreadPoolExecutor)pool).setKeepAliveTime(120,TimeUnit.SECONDS);
        ((ThreadPoolExecutor)pool).allowCoreThreadTimeOut(true);
        try(ServerSocket serverSocket = new ServerSocket(PORT)){
           while(true) {

                    Socket socket = serverSocket.accept();
                    socket.setSoTimeout(MAX_MINUTES_ONLINE*60*1000);

                    pool.execute(new ClientHandler(socket, k+1));
                    k+=1;

            }

        }
        catch(IOException e){
            throw new RuntimeException(e);
        }
        finally {
            pool.shutdown();
        }

    }
}

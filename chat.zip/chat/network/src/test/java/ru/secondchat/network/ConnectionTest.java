package ru.secondchat.network;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

import static org.junit.Assert.assertEquals;

public class ConnectionTest {

    ServerSocket serverSocket;
    Socket server;
    String received = "";
    Connection serverConnection;
    Connection clientConnection;

    @Before
    public void setUp() throws Exception {

        serverSocket = new ServerSocket(5001);
        testThread.start();
        server = serverSocket.accept();

        testThread.join();

        serverConnection = new Connection(new TestEventListener(), server);

    }

    @After
    public void tearDown() throws Exception {
        serverConnection.disconnect();
        clientConnection.disconnect();
        server.close();
        serverSocket.close();
        received = null;
        testThread = null;

    }

    @Test
    public void startNewChat() {
        clientConnection.startNewChat();
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        serverConnection.sendMessage("hello");
        assertEquals("праллельный примем сообщения на стороне клиента не работает", "hello", received);
        clientConnection.disconnect();
    }

    @Test
    public void sendMessage() {

        clientConnection.sendMessage("hello");
        try {
            received = serverConnection.recieveSingleMessage();
        } catch (IOException e) {
            e.printStackTrace();
        }
        assertEquals("server doesn't receive client messages", "hello",received);

    }

    @Test
    public void recieveSingleMessage() {

        serverConnection.sendMessage("test");
        try {
            received = clientConnection.recieveSingleMessage();
        } catch (IOException e) {}

        assertEquals("client doesn't receive agent messages", "test",received);
    }

    @Test
    public void disconnect() {
        clientConnection.disconnect();
        clientConnection.sendMessage("hello");
        try {
         received = serverConnection.recieveSingleMessage();
        } catch (IOException e) {
            e.printStackTrace();
        }
        assertEquals("не закрывается сокет", received, null);


    }

    private class TestEventListener implements ConnectionListener {
        @Override
        public void onConnectionReady(Connection connection) {

        }

        @Override
        public void onRegistration(Connection connection) {

        }

        @Override
        public void onReciveMessage(Connection connection, String value) {
            received = value;

        }

        @Override
        public void onDisconnect(Connection connection) {

        }

        @Override
        public void onException(Connection connection, Exception e) {

        }

        @Override
        public void processCommands(String value) {

        }
    }
    Thread testThread = new Thread(new Runnable() {
        @Override
        public void run() {
            try {
                Thread.sleep(100);
                clientConnection = new Connection(new TestEventListener(),"127.0.0.1", 5001 );
            } catch (IOException e) {}
            catch (InterruptedException e){}

        }
    });
}
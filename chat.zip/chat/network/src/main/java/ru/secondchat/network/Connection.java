package ru.secondchat.network;

import java.io.*;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.nio.charset.Charset;

public class Connection {

    private final Socket socket;
    private final Thread rxThread;
    private final ConnectionListener eventListener;
    private final BufferedReader in;
    private final PrintWriter out;

    public Connection(ConnectionListener eventListener, String ip, int port) throws IOException {
        this(eventListener, new Socket(ip, port));
    }

    public Connection(ConnectionListener event, Socket socket) throws IOException {
        this.eventListener = event;
        this.socket=socket;
        in = new BufferedReader(new InputStreamReader(socket.getInputStream(), Charset.forName("UTF-8")));
        out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), Charset.forName("UTF-8")), true);

        rxThread = new Thread(new Runnable() {
            @Override
            public void run() {
                try{

                    while(!rxThread.isInterrupted()){
                        try{

                        eventListener.onReciveMessage(Connection.this, Connection.this.recieveSingleMessage());}
                        catch(SocketTimeoutException e){
                            System.out.println("пришел таймаут");
                        }
                    }

                } catch(IOException e){
                    eventListener.onException(Connection.this, e);
                    System.out.println("срабатывает сразу");

                }
                finally {
                    eventListener.onDisconnect(Connection.this);

                }
            }
        });
    }

    public void startNewChat(){
        rxThread.start();
    }

    public synchronized void sendMessage(String value){
        if(value!=null){
        out.print(value);
        out.println();}
        else {eventListener.onException(Connection.this, new IOException());
            System.out.println("дисконектится то что не дложно");//вот здесь ошибка т.к. сразу пробуем переслать ноль не получается и дисконнектим всех
       // disconnect();

        }

    }

    public String recieveSingleMessage()throws IOException{

        return in.readLine();
    }

    public synchronized void disconnect(){
        rxThread.interrupt();
        try {
            socket.close();
        } catch (IOException e) {
            System.out.println("вызов эксептион из дисконнект");
            eventListener.onException(Connection.this, e);
        }

    }

    @Override
    public String toString() {
        return "TCP Connection: "+socket.getInetAddress()+": "+ socket.getPort();
    }
}

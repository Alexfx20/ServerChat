package ru.secondchat.network;

public interface ConnectionListener {

    void onConnectionReady(Connection connection);
    void onRegistration(Connection connection);
    void onReciveMessage(Connection connection, String value);
    void onDisconnect(Connection connection);
    void onException(Connection connection, Exception e);
    void processCommands(String value);
}
